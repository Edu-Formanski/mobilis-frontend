import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  justify-content: center;

  th {
    text-align: center;
  }

  td {
    text-align: center;
  }
`;
